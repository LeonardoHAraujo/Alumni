<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="div-btn-create">
    <button class="btn btn-info" id="create"><i class="fas fa-plus"></i></button>
</div>

<table id="datatable-buttons" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
    <thead>
        <tr>
            <th>Nome</th>
            <th>Sobrenome</th>
            <th>Email</th>
            <th>Celular</th>
            <th>Ações</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($lead->isActive === 1): ?>
                <tr>
                    <td><?php echo e($lead->name); ?></td>
                    <td><?php echo e($lead->lastName); ?></td>
                    <td><?php echo e($lead->email); ?></td>
                    <td><?php echo e($lead->cell); ?></td>
                    <td>
                        <button 
                            class="btn btn-success"
                            btn-view 
                            data-id="<?php echo e($lead->id); ?>"
                            data-name="<?php echo e($lead->name); ?>"
                            data-lastName="<?php echo e($lead->lastName); ?>"
                            data-company="<?php echo e($lead->company); ?>"
                            data-linkedin="<?php echo e($lead->linkedin); ?>"
                            data-formation="<?php echo e($lead->formation); ?>"
                            data-contactPoint="<?php echo e($lead->contactPoint); ?>"
                            data-dateFirstContact="<?php echo e($lead->dateFirstContact); ?>"
                            data-cell="<?php echo e($lead->cell); ?>"
                            data-telephone="<?php echo e($lead->telephone); ?>"
                            data-email="<?php echo e($lead->email); ?>"
                            data-emailSecondary="<?php echo e($lead->emailSecondary); ?>"
                            data-street="<?php echo e($lead->street); ?>"
                            data-number="<?php echo e($lead->number); ?>"
                            data-city="<?php echo e($lead->city); ?>"
                            data-state="<?php echo e($lead->state); ?>"
                            data-country="<?php echo e($lead->country); ?>"
                        >
                            <i class="fas fa-eye"></i>
                        </button>

                        <button 
                            class="btn btn-warning" 
                            btn-edit 
                            data-id="<?php echo e($lead->id); ?>"
                            data-name="<?php echo e($lead->name); ?>"
                            data-lastName="<?php echo e($lead->lastName); ?>"
                            data-company="<?php echo e($lead->company); ?>"
                            data-linkedin="<?php echo e($lead->linkedin); ?>"
                            data-formation="<?php echo e($lead->formation); ?>"
                            data-contactPoint="<?php echo e($lead->contactPoint); ?>"
                            data-dateFirstContact="<?php echo e($lead->dateFirstContact); ?>"
                            data-cell="<?php echo e($lead->cell); ?>"
                            data-telephone="<?php echo e($lead->telephone); ?>"
                            data-email="<?php echo e($lead->email); ?>"
                            data-emailSecondary="<?php echo e($lead->emailSecondary); ?>"
                            data-street="<?php echo e($lead->street); ?>"
                            data-number="<?php echo e($lead->number); ?>"
                            data-city="<?php echo e($lead->city); ?>"
                            data-state="<?php echo e($lead->state); ?>"
                            data-country="<?php echo e($lead->country); ?>"
                        >
                            <i class="fas fa-pencil-alt"></i>
                        </button>

                        <button type="submit" class="btn btn-primary" btn-delete data-id="<?php echo e($lead->id); ?>">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<!-- MODAL FORM -->
<div class="modal fade" role="dialog" id="modal">
    <div class="modal-dialog">
        <!-- Modal content-->
        <form action="" method="post">
            <div class="modal-content custom-modal">

                <?php echo csrf_field(); ?>

                <!-- Data id -->
                <input type="hidden" value="" id="id">

                <!-- Modal Header  -->
                <div class="modal-header">
                    <h4 class="modal-title" id="id-title-modal"></h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Message Alert validate -->
                <div class="alert width-alert hide" id="alert-message">
                    <!-- message dynamic here -->
                </div>
                
                <!-- Modal Body  -->
                <div class="modal-body">
                    <div class="divs-view">
                        <div class="form-group mx-sm-3 mb-2 width-input-view">
                            <label for="name">Nome</label>
                            <input type="text" id="name" class="form-control" placeholder="Nome...">
                        </div>
                        <div class="form-group mx-sm-3 mb-2 width-input-view">
                            <label for="name">Sobrenome</label>
                            <input type="text" id="lastName" class="form-control" placeholder="Sobrenome...">
                        </div>
                    </div>
                    <div class="divs-view">
                        <div class="form-group mx-sm-3 mb-2 width-input-view">
                            <label for="name">Empresa</label>
                            <input type="text" id="company" class="form-control" placeholder="Empresa...">
                        </div>
                        <div class="form-group mx-sm-3 mb-2 width-input-view">
                            <label for="name">LinkedIn</label>
                            <input type="text" id="linkedin" class="form-control" placeholder="LinkedIn...">
                        </div>
                    </div>
                    <div class="form-group mx-sm-3 mb-2">
                        <label for="name">Formação</label>
                        <input type="text" id="formation" class="form-control" placeholder="Formação...">
                    </div>
                    <div class="divs-view">
                        <div class="form-group mx-sm-3 mb-2 width-input-view">
                            <label for="name">Ponto de contato</label>
                            <input type="text" id="contactPoint" class="form-control" placeholder="Ponto de contato...">
                        </div>
                        <div class="form-group mx-sm-3 mb-2 width-input-view">
                            <label for="name">Data do primeiro contato</label>
                            <input type="date" id="dateFirstContact" class="form-control" placeholder="Data...">
                        </div>
                    </div>
                    <div class="divs-view">
                        <div class="form-group mx-sm-3 mb-2 width-input-view">
                            <label for="name">Celular</label>
                            <input type="text" id="cell" class="form-control" placeholder="Celular...">
                        </div>
                        <div class="form-group mx-sm-3 mb-2 width-input-view">
                            <label for="name">Telefone</label>
                            <input type="text" id="telephone" class="form-control" placeholder="Telefone...">
                        </div>
                    </div>
                    <div class="form-group mx-sm-3 mb-2">
                        <label for="name">E-mail</label>
                        <input type="email" id="email" class="form-control" placeholder="E-mail...">
                    </div>
                    <div class="form-group mx-sm-3 mb-2">
                        <label for="name">E-mail Secundário</label>
                        <input type="email" id="emailSecondary" class="form-control" placeholder="E-mail Secundário...">
                    </div>

                    <div class="divs-view bottom-locale">
                        <div class="form-group mx-sm-3 mb-2 width-input-view">
                            <label for="name">Localidade</label>
                            <input type="text" id="street" class="form-control" placeholder="Rua...">
                        </div>
                        <div class="form-group mx-sm-3 mb-2 width-input-view">
                            <label for="name">&nbsp</label>
                            <input type="text" id="number" class="form-control" placeholder="Número...">
                        </div>
                    </div>
                    <div class="divs-view">
                        <div class="form-group mx-sm-3 mb-2 width-input-view">
                            <label for="name">&nbsp</label>
                            <input type="text" id="city" class="form-control" placeholder="Cidade...">
                        </div>
                        <div class="form-group mx-sm-3 mb-2 width-input-view">
                            <label for="name">&nbsp</label>
                            <input type="text" id="state" class="form-control" placeholder="Estado...">
                        </div>
                        <div class="form-group mx-sm-3 mb-2 width-input-view">
                            <label for="name">&nbsp</label>
                            <input type="text" id="country" class="form-control" placeholder="País...">
                        </div>
                    </div>
                </div>

                <!-- Modal Footer  -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary" id="confirm">Confirmar</button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- MODAL VIEW DATA -->
<div id="modal-view" class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content custom-modal">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="myLargeModalLabel">Visualização do(a) Lead <b><span id="nameLead"> <!-- Dynamic name here --> </span></b> </h5>
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
            </div>
            <div class="modal-body">
                <div class="divs-view">
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">Nome</label>
                        <input type="text" id="nameView" class="form-control" data-disabled>
                    </div>
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">Sobrenome</label>
                        <input type="text" id="lastNameView" class="form-control" data-disabled>
                    </div>
                </div>
                
                <div class="divs-view">
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">Empresa</label>
                        <input type="text" id="companyView" class="form-control" data-disabled>
                    </div>
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">LinkedIn</label>
                        <input type="text" id="linkedinView" class="form-control" data-disabled>
                    </div>
                </div>
                
                <div class="divs-view">
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">Formação</label>
                        <input type="text" id="formationView" class="form-control" data-disabled>
                    </div>
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">Ponto de contato</label>
                        <input type="text" id="contactPointView" class="form-control" data-disabled>
                    </div>
                </div>
                
                <div class="divs-view">
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">Data do primeiro contato</label>
                        <input type="text" id="dateFirstContactView" class="form-control" data-disabled>
                    </div>
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">Celular</label>
                        <input type="text" id="cellView" class="form-control" data-disabled>
                    </div>
                </div>

                <div class="divs-view">
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">Telefone</label>
                        <input type="text" id="telephoneView" class="form-control" data-disabled>
                    </div>
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">E-mail</label>
                        <input type="text" id="emailView" class="form-control" data-disabled>
                    </div>
                </div>

                
                <div class="divs-view">
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">E-mail Secundário</label>
                        <input type="text" id="emailSecondaryView" class="form-control" data-disabled>
                    </div>
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">Rua</label>
                        <input type="text" id="streetView" class="form-control" data-disabled>
                    </div>
                </div>

                <div class="divs-view">
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">Número</label>
                        <input type="text" id="numberView" class="form-control" data-disabled>
                    </div>
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">Cidade</label>
                        <input type="text" id="cityView" class="form-control" data-disabled>
                    </div>
                </div>
                <div class="divs-view">
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">Estado</label>
                        <input type="text" id="stateView" class="form-control" data-disabled>
                    </div>
                    <div class="form-group mx-sm-3 mb-2 width-input-view">
                        <label for="name">País</label>
                        <input type="text" id="countryView" class="form-control" data-disabled>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- Friendly alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!-- Required datatable js -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/customer.min.js')); ?>"></script>

    <!-- Buttons examples -->
    <script src="<?php echo e(asset('plugins/datatables/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/buttons.colVis.min.js')); ?>"></script>

    <!-- Datatable init js -->
    <script src="<?php echo e(asset('assets/pages/datatables.init.js')); ?>"></script>

    <!-- export to Excel -->
    <script src="//cdn.rawgit.com/rainabba/jquery-table2excel/1.1.0/dist/jquery.table2excel.min.js"></script> 

    <!-- My script -->
    <script src="<?php echo e(asset('js/leads/leads.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/leonardo/Imagens/Alumni/resources/views/admin/leads/leads.blade.php ENDPATH**/ ?>