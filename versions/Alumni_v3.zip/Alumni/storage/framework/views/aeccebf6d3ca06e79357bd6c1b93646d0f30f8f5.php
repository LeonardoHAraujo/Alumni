<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>
    <!-- DataTables -->
    <link href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('plugins/datatables/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('plugins/datatables/responsive.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo csrf_field(); ?>

<table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
    <thead>
        <tr>
            <th>Nome</th>
            <th>E-mail</th>
            <th>Função</th>
            <th>Reativar</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($user->isActive === 0): ?>
                <tr>
                    <td><?php echo e($user->name); ?> <?php echo e($user->lastName); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td>
                        <?php if($user->isAdmin == 1): ?>
                            <span class="alert alert-dark color-span">Admin</span>
                        <?php else: ?>
                            <span class="alert alert-info color-span pd-right">Aluno</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <button type="submit" class="btn btn-success waves-effect waves-light" btn-reactivate data-id="<?php echo e($user->id); ?>">
                            <i class="fas fa-users"></i>
                        </button>
                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- Friendly alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <!-- Required datatable js -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

    <!-- Datatable init js -->
    <script src="<?php echo e(asset('assets/pages/datatables.init.js')); ?>"></script>

    <!-- My script -->
    <script src="<?php echo e(asset('js/user/deletedUser.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/leonardo/Documentos/Alumni/resources/views/admin/settings/deletedUsers.blade.php ENDPATH**/ ?>