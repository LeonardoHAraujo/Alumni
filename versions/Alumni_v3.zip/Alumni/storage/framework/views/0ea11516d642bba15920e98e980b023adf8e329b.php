<?php $__env->startSection('title'); ?>
    <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('welcome'); ?>
    Bem vindo à página principal
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div class="row center-cards">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary mini-stat position-relative width-card">
                <div class="card-body">
                    <div class="mini-stat-desc">
                        <h6 class="text-uppercase verti-label text-white-50">Leads</h6>
                        <div class="text-white">
                            <h6 class="text-uppercase mt-0 text-white-50">Leads</h6>
                            <h3 class="mb-3 mt-0"><?php echo e($countLeads); ?></h3>
                            <div class="">
                                <!--<span class="badge badge-light text-info"> +11% </span>--> <span class="ml-2">Número de Leads do sistema</span>
                            </div>
                        </div>
                        <div class="mini-stat-icon">
                            <i class="mdi mdi-cube-outline display-2"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary mini-stat position-relative width-card">
                <div class="card-body">
                    <div class="mini-stat-desc">
                        <h6 class="text-uppercase verti-label text-white-50">Usuarios</h6>
                        <div class="text-white">
                            <h6 class="text-uppercase mt-0 text-white-50">Usuarios</h6>
                            <h3 class="mb-3 mt-0"><?php echo e($countUser); ?></h3>
                            <div class="">
                                <!--<span class="badge badge-light text-danger"> -29% </span>--> <span class="ml-2">Número de Usuarios do sistema</span>
                            </div>
                        </div>
                        <div class="mini-stat-icon">
                            <i class="mdi mdi-buffer display-2"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary mini-stat position-relative width-card">
                <div class="card-body">
                    <div class="mini-stat-desc">
                        <h6 class="text-uppercase verti-label text-white-50">Us. Delet.</h6>
                        <div class="text-white">
                            <h6 class="text-uppercase mt-0 text-white-50">Usuarios Deletados</h6>
                            <h3 class="mb-3 mt-0"><?php echo e($countUserDeleted); ?></h3>
                            <div class="">
                                <!--<span class="badge badge-light text-primary"> 0% </span>--> <span class="ml-2">Número de Usuarios Deletados</span>
                            </div>
                        </div>
                        <div class="mini-stat-icon">
                            <i class="mdi mdi-tag-text-outline display-2"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-6">
            <div class="card">
                <div class="card-body">
                    <h4 class="mt-0 header-title mb-4">Primeiros Usuários</h4>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th scope="col">Name</th>
                                    <th scope="col">Sobrenome</th>
                                    <th scope="col">Email</th>
                                    <th scope="col" colspan="2">Função</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $usersLimit5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($users->isActive === 1): ?>
                                        <tr>
                                            <td>
                                                <div>
                                                    <?php echo e($users->name); ?>

                                                </div>
                                            </td>
                                            <td><?php echo e($users->lastName); ?></td>
                                            <td><?php echo e($users->email); ?></td>
                                            
                                            <?php if($users->isAdmin === 1): ?>
                                                <td><span class="badge badge-dark">Admin</span></td>
                                            <?php else: ?>
                                                <td><span class="badge badge-info">Aluno</span></td>
                                            <?php endif; ?>

                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>


        <div class="col-xl-6">
            <div class="card">
            <div class="card-body">
                    <h4 class="mt-0 header-title mb-4">Primeiros Leads</h4>
                    <div class="table-responsive">
                        <table class="table table-hover mb-0">
                            <thead>
                                <tr>
                                    <th scope="col">Name</th>
                                    <th scope="col">Sobrenome</th>
                                    <th scope="col">Empresa</th>
                                    <th scope="col" colspan="2">Cidade</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $leadsLimit5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($leads->isActive === 1): ?>
                                        <tr>
                                            <td>
                                                <div>
                                                    <?php echo e($leads->name); ?>

                                                </div>
                                            </td>
                                            <td><?php echo e($leads->lastName); ?></td>
                                            <td><?php echo e($leads->company); ?></td>
                                            <td><?php echo e($leads->city); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/leonardo/Imagens/Alumni/resources/views/admin/panel-admin.blade.php ENDPATH**/ ?>