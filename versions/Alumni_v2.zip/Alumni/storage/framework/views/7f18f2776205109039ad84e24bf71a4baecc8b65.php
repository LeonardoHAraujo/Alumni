<h1>Students</h1>
<a href="<?php echo e(route('logout')); ?>">Logout</a>
<?php /**PATH /home/leonardo/Documentos/Alumni/resources/views/pages/students.blade.php ENDPATH**/ ?>