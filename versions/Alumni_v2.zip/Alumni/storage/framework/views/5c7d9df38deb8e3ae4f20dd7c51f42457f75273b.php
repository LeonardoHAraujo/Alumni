<h1>Dashboard admin</h1>
<a href="<?php echo e(route('logout')); ?>">Logout</a>
<?php /**PATH /home/leonardo/Documentos/ponto-web/resources/views/admin/panel-admin.blade.php ENDPATH**/ ?>