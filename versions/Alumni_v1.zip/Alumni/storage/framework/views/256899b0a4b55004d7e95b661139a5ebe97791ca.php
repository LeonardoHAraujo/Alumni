<h1>relógio de ponto</h1>
<a href="<?php echo e(route('logout')); ?>">Logout</a>
<?php /**PATH /home/leonardo/Documentos/ponto-web/resources/views/pointWeb/clock.blade.php ENDPATH**/ ?>