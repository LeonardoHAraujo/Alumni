<h1>Students</h1>
<a href="{{ route('logout') }}">Logout</a>
