Alumni Antebellum

    run git clone https://github.com/LeonardoHAraujo/Alumni.git
    run composer update for installing dependencies
    create a new database laravel
    run php artisan key:generate
    run php artisan migrate
    run php artisan serve